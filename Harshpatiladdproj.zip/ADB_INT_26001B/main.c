/*
===============================================================================
Author        : Harsh S patil
Date          : 17/06/2026
File Name     : main.c
Description   : Implementation of the Address Book Project.
                This program allows users to create, view, edit, search, 
                and delete contact information such as name, phone number, 
                and email address. The data is managed dynamically and can 
                be stored or retrieved efficiently.

Sample Execution:
-------------------------------------------------------------------------------
Test Case 1:
1. Create contact
2. Search contact
3. Edit contact
4. Delete contact
5. List all contacts
6. Save contacts
Enter your choice : 1

Enter Name        : Johnny Doe
Enter Phone Number: 9874561232
Enter Email ID    : johnny.doe@gmail.com

Contact added successfully!

-------------------------------------------------------------------------------
Test Case 2:
Enter your choice : 5

--- Contact List ---
1   Johnny Doe  9874561232  johnny.doe@example.com
-------------------------------------------------------------------------------

Output:
Displays, edits, or manages contact details based on user input.
===============================================================================
*/



#include<stdio.h>
#include "contact.h"
/* Structure declaration */

int main()
{
    /* Variable and structre defintion */
    int option;
    struct AddressBook addressbook;
    addressbook.contact_count = 0;

    while (1)
    {
        printf("\nAddress book menu\n"); /* Give a prompt message for a user */
        printf("1.Add contact\n2.search contact\n3.Edit contact\n4.Delete contact\n5.Display contact\n6.Save contact\n7.Exit\n");
        printf("Enter the option : ");
        scanf("%d", &option);

        switch (option) /* Based on choosed option */
        {
        case 1:
        {
            create_contact(&addressbook);  
            break;
        }

        case 2:
        {
            printf("Search Contact menu : \n1.Name \n2.Mobile number\n3.Mail ID\n4. Exit\nEnter the option : "); 
            search_contacts(&addressbook);
            break;
        }
        case 3:
            printf("Edit Contact menu : \n1.Name \n2.Mobile number\n3.Mail ID\n4.Exit\nEnter the option : "); 

            edit_contact(&addressbook);
            break;
            //-----Delete contact----

        case 4:
        {
            printf("Delete Contact menu : \n1.Name \n2.Mobile number\n3.Mail ID\n4.Exit\nEnter the option : "); 
            delete_contact(&addressbook);
            break;
        }
        //-----Listing contacts-----
        case 5:
        {
            printf("List Contacts:");
            list_contacts(&addressbook);
            break;
        }
        case 6:
        {
            printf("Save contact:");
            save_contacts(&addressbook);
            break;
        }

        case 7:
            printf("Exit\n");
            return 0;


        default:
            printf("Invalid option \n");
            break;
       }
     }
     return 0;
}
