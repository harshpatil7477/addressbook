/*
-----------------------------------------------------------------------------------------------------------------------------------
Author        : Harsh S Patil
Date          : 17/06/2026
File Name     : contact.c
Description   : Implementation of the Address Book Project.
                This program allows users to create, view, edit, search,
                and delete contact information such as name, phone number,
                and email address. The data is managed dynamically and can
                be stored or retrieved efficiently.
-------------------------------------------------------------------------------------------------------------------------------------
*/



#include "contact.h"
#include<stdio.h>
#include <stdlib.h>
#include<string.h>


// Function Definitions

int createname(char *name);
int createphone(char*phone);
int createemail(char *email);
 

void create_contact( struct AddressBook *addressbook)
{
 

    char Name[50];
    char Phone[11];
    char Email[20];
int n,p,e;

///////////////Name
do
{
    int i=0;
    printf("Enter the Name: ");
    scanf(" %[^\n]",Name);
    n=createname(Name);
 

        if(n==0)
            printf("Error!: Invaild name\n");
}while(n==0);


 strcpy(addressbook->contact_details[addressbook->contact_count].Name, Name);
   
////////////////phone number
do
{
    printf("Enter phone number: ");
    scanf(" %[^\n]",Phone);
    p=createphone(Phone);
    int i=0,f=0;
    for(int i=0;i<addressbook->contact_count;i++)
    {
        if(strcmp(addressbook->contact_details[i].Mobile_number,Phone)==0)
        {
            printf("Error!: contact Already Exist\n");
            p=0;
            break;
        }
    }
}while(p == 0);

 strcpy(addressbook->contact_details[addressbook->contact_count].Mobile_number, Phone);


/////////// Taking Email from the user
    do
    {
        printf("Enter E-mail address: ");
        scanf(" %[^\n]", Email);

        e = createemail(Email); // function call for Email

        int i = 0, f = 0;
        while (i < addressbook->contact_count)
        {
            f = strcmp(addressbook->contact_details[i].Mail_ID, Email);

            if (f == 0)
            {
                printf("Email ALready exist\n");
                e = 0;
                break; // Stop checking further no need
            }
            i++;
        }
        if (e == 0)
        {
            printf("Error! : Invalid email\n");
        }
    } while (e == 0);

    strcpy(addressbook->contact_details[addressbook->contact_count].Mail_ID, Email);

    addressbook->contact_count++;
    printf("Contact Created Succesfully\n");
}

//////////////// name validation

 int createname(char *name){
    int i=0;
    while(name[i])
    {
        if(!((name[i]>='a' && name[i]<='z') || 
        (name[i]>='A' && name[i]<='Z')|| 
        name[i]== ' '))
        {
            return 0;
        }
        if(name[i]==' ' && name[i+1]==' ')
        {
           return 0;
        }
        i++;
    }
    return 1;
}
//////////////Phone validation
 
 int createphone(char*phone)
 {
 int i=0,len;
 len=strlen(phone);
 while(phone[i])
 {
    if(!(phone[i]>='0' && phone[i]<='9'))
    {
         printf("Error! : All Elements should be numbers\n");
            return 0;
 }
 i++;
}
if(phone[0]=='0' || phone[0]=='1')
{
    printf("Error! :Invalid starting digit\n");
    return 0;
}

if(!(len == 10))
{
    printf("Phone number must be 10 digit\n");
        return 0;
    }
    return 1;
}

//////////////////////////////////////////////////////////////// Email Validation




int createemail(char *email)
{
    int i = 0, len = strlen(email), count = 0;

    if (email[0] == '@' || email[0] == '.' || email[len - 1] == '@' || email[len - 1] == '.')
    {
        return 0;
    }
    char *p = strchr(email, '@');
    if (p == NULL)
    {
        return 0;
    }
    if (!(strstr(p, ".com") || strstr(p, ".in") || strstr(p, ".edu")))
    {
        return 0;
    }

    while (email[i])
    {
        if (!(email[i] >= 'a' && email[i] <= 'z' || email[i] == '@' || email[i] == '.' || email[i] >= '0' && email[i] <= '9'))
        {
            return 0;
        }

        if (email[i] == '@')
        {
            count++;
            if (count != 1)
            {
                return 0;
            }
        }

        if (email[i] == '@' && email[i + 1] == '@' || email[i] == '.' && email[i + 1] == '.')
        {
            return 0;
        }
        i++;
    }
    return 1;
}
/////////////////////List contacts
   


void  list_contacts(struct AddressBook *addressbook)
{


    // Displaying all contacts which are saved
    int n = addressbook->contact_count;
   

    // Listing a contacts
    printf("\n---------------------------------------------------------------");
    printf("\n%-10s %-15s %-15s %-25s\n", "S.No", "Name", "Phone", "Email");
    printf("---------------------------------------------------------------\n");

    for (int i = 0; i < addressbook->contact_count; i++)
    {
        printf("%d\t %s\t %s\t %s\n", i + 1, addressbook->contact_details[i].Name, addressbook->contact_details[i].Mobile_number, addressbook->contact_details[i].Mail_ID);
    }
    printf("---------------------------------------------------------------\n");
}
/////////////////////Search contact


void search_contacts(struct AddressBook *addressbook)
{
    /* Define the logic for search */
    char Name[50];
    char Mobile_number[20];
    char Mail_ID[50];
    int count = addressbook->contact_count;

    int choice;
    do
    {
        printf("\n--------------------------\n");
        printf("Enter Search By: \n");
        printf("1).Name\n2).Phone\n3).Email\n4).Back To Menu\n");
        printf("\n--------------------------\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        if (choice == 4)
        {
            break;
        }

        int flag = 0;
        if (choice == 1)
{
    printf("Enter Your Name: ");
    scanf(" %[^\n]", Name);

    int foundcount = 0;
    int foundindex[100];

    for (int i = 0; i < count; i++)
    {
        if (strcasecmp(addressbook->contact_details[i].Name, Name) == 0)
        {
            foundindex[foundcount++] = i;
        }
    }

    if (foundcount == 0)
    {
        printf("Not Found!\n");
    }
    else if (foundcount == 1)
    {
        int i = foundindex[0];

        printf("%d\t%s\t%s\t%s\n",
               i + 1,
               addressbook->contact_details[i].Name,
               addressbook->contact_details[i].Mobile_number,
               addressbook->contact_details[i].Mail_ID);
    }
    else
    {
        printf("\nMultiple Users Found (%d)\n", foundcount);

        for (int j = 0; j < foundcount; j++)
        {
            int i = foundindex[j];

            printf("%d\t%s\t%s\t%s\n",
                   i + 1,
                   addressbook->contact_details[i].Name,
                   addressbook->contact_details[i].Mobile_number,
                   addressbook->contact_details[i].Mail_ID);
        }

        char phone[20];
        printf("\nEnter Phone Number: ");
        scanf(" %[^\n]", phone);

        int found = 0;

        for (int j = 0; j < foundcount; j++)
        {
            int i = foundindex[j];

            if (strcmp(addressbook->contact_details[i].Mobile_number, phone) == 0)
            {
                printf("\nSelected Contact:\n");
                printf("%d\t%s\t%s\t%s\n",
                       i + 1,
                       addressbook->contact_details[i].Name,
                       addressbook->contact_details[i].Mobile_number,
                       addressbook->contact_details[i].Mail_ID);

                found = 1;
                break;
            }
        }

        if (!found)
        {
            printf("Phone Number Not Matched!\n");
        }
    }
}
        else if (choice == 2)
        {
            printf("Enter Your Phone: ");
            scanf(" %[^\n]", Mobile_number);

            for (int i = 0; i < count; i++)
            {
                if (strcmp(addressbook->contact_details[i].Mobile_number, Mobile_number) == 0)
                {
                    printf("%d\t %s\t %s\t %s\n", i + 1, addressbook->contact_details[i].Name, addressbook->contact_details[i].Mobile_number, addressbook->contact_details[i].Mail_ID);
                    flag = 1;
                    continue;
                }
            }
            if (!flag)
            {
                printf("Not Found!\n");
            }
        }

        else if (choice == 3)
        {
            printf("Enter Your Email: ");
            scanf(" %[^\n]", Mail_ID);
            for (int i = 0; i < count; i++)
            {
                if (strcmp(addressbook->contact_details[i].Mail_ID,Mail_ID) == 0)
                {
                    printf("%d\t %s\t %s\t %s\n", i + 1, addressbook->contact_details[i].Name, addressbook->contact_details[i].Mobile_number, addressbook->contact_details[i].Mail_ID);
                    flag = 1;
                    continue;
                }
            }
            if (!flag)
            {
                printf("Not Found!\n");
            }
        }

        else
        {
            printf("\n--------------------------\n");
            printf("\nInvalid Choice! Enter Again\n");
        }

    } while (choice != 4);
}


/////edit contact
 


void edit_contact(struct AddressBook *addressbook)
{
    /* Define the logic for Editcontact */
    char searchkey[50];
    int count = addressbook->contact_count;

    int choice;
    do
    {
        printf("\n--------------------------\n");
        printf("Enter Search By: \n");
        printf("1).Name\n2).Phone\n3).Email\n4).Back To Menu\n");
        printf("--------------------------\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        if (choice == 4)
        {
            return;
        }

        int foundcount = 0;
        int foundindex[100];

        printf("Enter name/phone/email to edit : \n");
        scanf(" %[^\n]", searchkey);

        for (int i = 0; i < addressbook->contact_count; i++)
        {
            int match = 0;

            if (choice == 1 && strcasecmp(addressbook->contact_details[i].Name, searchkey) == 0)
            {
                match = 1;
            }

            else if (choice == 2 && strcmp(addressbook->contact_details[i].Mobile_number, searchkey) == 0)
            {
                match = 1;
            }

            else if (choice == 3 && strcasecmp(addressbook->contact_details[i].Mail_ID, searchkey) == 0)
            {
                match = 1;
            }

            if (match)
            {
                foundindex[foundcount++] = i; // separate array used to store duplicates
                printf("[%d] %s | %s | %s\n", foundcount,
                       addressbook->contact_details[i].Name,
                       addressbook->contact_details[i].Mobile_number,
                       addressbook->contact_details[i].Mail_ID);
            }
        }
        if (foundcount == 0)
        {
            printf("---Contact Not Found Can You Please Enter Again---\n");
            continue;
        }

        int select;
        if (foundcount > 1)
        {
            printf("\nMultiple contacts found! Choose which one to edit (1-%d): ", foundcount);
            scanf("%d", &select);
            if (select < 1 || select > foundcount)
            {
                printf("Invalid choice.\n");
                continue;
            }
        }
        else
        {
            select = 1; // if thers is only one contact present means by default select is 1.
        }

        int index = foundindex[select - 1];

        printf("\nEditing Contact:\n");
        printf("%s | %s | %s\n",
               addressbook->contact_details[index].Name,
               addressbook->contact_details[index].Mobile_number,
               addressbook->contact_details[index].Mail_ID);

        int editChoice;
        printf("\nWhat do you want to update?\n");
        printf("1).Name\n2).Phone\n3).Email\n");
        printf("Enter your choice: ");
        scanf("%d", &editChoice);

        switch (editChoice)
        {
        case 1:
            printf("Enter new name: ");
            scanf(" %[^\n]", addressbook->contact_details[index].Name);
            break;

        case 2:
            printf("Enter new phone: ");
            scanf(" %[^\n]", addressbook->contact_details[index].Mobile_number);
            break;

        case 3:
            printf("Enter new email: ");
            scanf(" %[^\n]", addressbook->contact_details[index].Mail_ID);
            break;

        default:
            printf("Invalid choice!\n");
            break;
        }
        printf("\nContact updated successfully!\n");
        printf("%s | %s | %s\n",
               addressbook->contact_details[index].Name,
               addressbook->contact_details[index].Mobile_number,
               addressbook->contact_details[index].Mail_ID);

    } while (choice != 4);
}

/////////////////delete contact



void delete_contact(struct AddressBook *addressbook)
 {
    
  /* Define the logic for deletecontact */

    if (addressbook->contact_count == 0)
    {
        printf("No contacts to delete\n");
    }

    int deletechoice;
    char searchkey[50];
    int foundindex[50];
    int foundcount = 0;

    do
    {
        printf("Select your choice to delete by\n");
        printf("1.Delete By Name\n");
        printf("2.Delete By Phone_num\n");
        printf("3.Delete By Email\n");
        printf("Enter your choice: ");
        scanf("%d", &deletechoice);
    } while (deletechoice < 1 || deletechoice > 3);

    printf("Enter name/phone/email to delete: ");
    scanf(" %[^\n]", searchkey);

    for (int i = 0; i < addressbook->contact_count; i++)
    {
        int match = 0;

        if (deletechoice == 1 && strcasecmp(addressbook->contact_details[i].Name, searchkey) == 0)
        {
            match = 1;
        }

        else if (deletechoice == 2 && strcmp(addressbook->contact_details[i].Mobile_number, searchkey) == 0)
        {
            match = 1;
        }

        else if (deletechoice == 3 && strcasecmp(addressbook->contact_details[i].Mail_ID, searchkey) == 0)
        {
            match = 1;
        }

        if (match)
        {
            foundindex[foundcount++] = i; // separate array used to store duplicates
            printf("[%d] %s | %s | %s\n", foundcount,
                   addressbook->contact_details[i].Name,
                   addressbook->contact_details[i].Mobile_number,
                   addressbook->contact_details[i].Mail_ID);
        }
    }
    if (foundcount == 0)
    {
        printf("---Contact Not Found Can You Please Enter Again---\n");
    }

    int delChoice = 1;
    if (foundcount > 1)
    {
        printf("\n\nMultiple contacts found! Enter number to delete (1-%d): ", foundcount);
        scanf("%d", &delChoice);

        if (delChoice < 1 || delChoice > foundcount)
        {
            printf("Invalid choice. Deletion cancelled.\n");
            return;
        }
    }

    int k = foundindex[delChoice - 1];

    // shift elements left after deletion
    for (int j = k; j < addressbook->contact_count - 1; j++)
    {
        addressbook->contact_details[j] = addressbook->contact_details[j + 1];
    }

    addressbook->contact_count--;
    printf("\n---Contact Deleted Successfully---\n");
}

///////////////////save contact

 
void save_contacts(struct AddressBook *addressbook)
{
    FILE *fptr = fopen("contacts.csv", "w");
    fprintf(fptr, "#%d\n", addressbook->contact_count);
    for (int i = 0; i < addressbook->contact_count; i++)
    {
        fprintf(fptr, "%s,%s,%s\n", addressbook->contact_details[i].Name, addressbook->contact_details[i].Mobile_number, addressbook->contact_details[i].Mail_ID);
    }

    fclose(fptr);
}
void loadContactsFromFile(struct AddressBook *addressbook)
{
    FILE *fptr = fopen("contacts.csv", "r");
    fscanf(fptr, "#%d\n", &addressbook->contact_count);
    for (int i = 0; i < addressbook->contact_count; i++)
    {
        fscanf(fptr, "%[^,],%[^,],%[^\n]\n", addressbook->contact_details[i].Name, addressbook->contact_details[i].Mobile_number, addressbook->contact_details[i].Mail_ID);
    }

    fclose(fptr);
}