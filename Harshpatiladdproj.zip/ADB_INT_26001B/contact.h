/*
-----------------------------------------------------------------------------------------------------------------------------------
Author        : Harsh S Patil
Date          : 17/06/2026
File Name     : contact.h
Description   : Implementation of the Address Book Project.
                This program allows users to create, view, edit, search,
                and delete contact information such as name, phone number,
                and email address. The data is managed dynamically and can
                be stored or retrieved efficiently.
-------------------------------------------------------------------------------------------------------------------------------------
*/
#ifndef CONTACT_H
#define CONTACT_H

#include <stdio.h>

struct Contacts
{
    char Name[20];
    char Mobile_number[11];
    char Mail_ID[20];
};

struct AddressBook
{
    struct Contacts contact_details[100];
    int contact_count;
};
/* Function declarations */

void create_contact(struct AddressBook *);
void list_contacts(struct AddressBook *);
void search_contacts(struct AddressBook *);
void edit_contact(struct AddressBook *);
void delete_contact(struct AddressBook *);
void save_contacts(struct AddressBook *);
void loadContactsFromFile(struct AddressBook *);

#endif


/* Function declarations */